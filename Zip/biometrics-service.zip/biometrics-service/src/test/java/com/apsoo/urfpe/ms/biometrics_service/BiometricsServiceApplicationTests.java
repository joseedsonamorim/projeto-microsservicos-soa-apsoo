package com.apsoo.urfpe.ms.biometrics_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiometricsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
