package com.apsoo.urfpe.ms.turnstile_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurnstileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
